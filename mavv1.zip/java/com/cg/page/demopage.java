package com.cg.page;

import java.util.regex.Pattern;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class demopage {

	WebDriver driver;
	@FindBy(name = "firstname")
	@CacheLookup
	WebElement fname;

	@FindBy(name = "lastname")
	@CacheLookup
	WebElement lname;

	@FindBy(name = "email")
	@CacheLookup
	WebElement email;

	@FindBy(name = "telephone")
	@CacheLookup
	WebElement telephone;

	@FindBy(name = "password")
	@CacheLookup
	WebElement password;

	@FindBy(name = "confirm")
	@CacheLookup
	WebElement confirm;

	@FindBy(xpath = "//*[@id=\"content\"]/form/fieldset[3]/div/div/label[2]/input")
	@CacheLookup
	WebElement subscribe;

	@FindBy(name = "agree")
	@CacheLookup
	WebElement agree;

	@FindBy(xpath = "//*[@id=\"content\"]/form/div/div/input[2]")
	@CacheLookup
	WebElement regcon;

	public void firstName(String first) {

		if (Pattern.matches("[a-zA-Z]{1,32}", first)) {
			fname.sendKeys(first);
		} else {
			System.out.println("Enter Valid First Name!");
		}
	}

	public void lasttName(String last) {

		if (Pattern.matches("[a-zA-Z]{1,32}", last)) {
			lname.sendKeys(last);
		} else {
			System.out.println("Enter Valid Last Name!");
		}

	}

	public void email(String mail) {

		if (Pattern.matches("\\b[A-Z0-9._%-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}\\b", mail)) {
			email.sendKeys(mail);
		} else {
			System.out.println("Enter Valid Email!");
		}
	}

	public void phone(String phone) {

		if (Pattern.matches("[7/8/9]{1}[0-9]{3,32}", phone)) {
			telephone.sendKeys(phone);
		} else {
			System.out.println("Enter Valid Phone!");
		}

	}

	public void Password(String pswd) {
		if(Pattern.matches("[a-zA-Z0-9]{4,20}", pswd)) {
			password.sendKeys(pswd);	
		}else {
			System.out.println("Enter Valid Password!");
		}
		
	}

	public void conpwd(String conpwd) {
		if(password.getText().equals(conpwd)) {
			confirm.sendKeys(conpwd);
		}
		else {
			System.out.println("Confrim Password should match Password");
		}

	}

	public void subscribe() {
		subscribe.click();
	}

	public void agree() {
		agree.click();
	}

	public void RegContinue() {
		regcon.click();
	}

	public demopage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
}
