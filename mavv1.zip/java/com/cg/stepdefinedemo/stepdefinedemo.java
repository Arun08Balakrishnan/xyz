package com.cg.stepdefinedemo;

import java.util.concurrent.TimeUnit;

import org.junit.BeforeClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import com.cg.page.demopage;

import cucumber.api.DataTable;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class stepdefinedemo {

	WebDriver driver;
	demopage dp;
	
	@Before
	public void before() {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "\\Driver\\chromedriver.exe");
		 driver = new ChromeDriver();
		 driver.get("http://demo.opencart.com/");
	}
	
	
	@Given("^The user is in register page$")
	public void The_user_is_in_register_page(){
		

		// verify title
		String actualTitle = driver.getTitle();
		System.out.println("Title of the web page : " + actualTitle);

		String title = "Your Store";
		if (actualTitle.equals(title)) {
			System.out.println("Test case is passed");
		} else {
			System.out.println("Test case is failed");
		}
		
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		WebElement myacc = driver.findElement(By.xpath("//*[@id='top-links']/ul/li[2]/a"));
		myacc.click();

		WebElement reg = driver.findElement(By.xpath("//*[@id=\'top-links\']/ul/li[2]/ul/li[1]/a"));
		reg.click();
	 
		dp = new demopage(driver);
	}
	
	@When("^User enters firstname as \"([^\"]*)\"$")
	public void user_enters_firstname_as(String fname) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		dp.firstName(fname);
		
	}

	@When("^User enters lastname as \"([^\"]*)\"$")
	public void user_enters_lastname_as(String lname) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		dp.lasttName(lname);
	}

	@When("^User enter email as \"([^\"]*)\"$")
	public void user_enter_email_as(String mail) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		dp.email(mail);
	}

	@When("^User enter telephone as (\\d+)$")
	public void user_enter_telephone_as(String phone) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		dp.phone(phone);
	}

	@When("^User enter password as \"([^\"]*)\"$")
	public void user_enter_password_as(String pswd) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		dp.Password(pswd);
	}

	@When("^User enter confirmpwd as \"([^\"]*)\"$")
	public void user_enter_confirmpwd_as(String conpwd) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		dp.conpwd(conpwd);
	}

	@When("^User select No subscribe$")
	public void user_select_No_subscribe() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		dp.subscribe();
	}

	@When("^User checks privacy policy$")
	public void user_checks_privacy_policy() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		dp.agree();
	}

	@Then("^Click continue$")
	public void click_continue() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		dp.RegContinue();
	}

	@When("^User enters firstname$")
	public void user_enters_firstname() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		dp.firstName("virat");
	}

	@When("^User enters lastname$")
	public void user_enters_lastname() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		dp.lasttName(" ");
		
	}

	@When("^User enter email$")
	public void user_enter_email() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		dp.email("virat@gmail.com");
	}

	@When("^User enter telephone$")
	public void user_enter_telephone() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		dp.phone("");
		
	}

	@When("^User enter password$")
	public void user_enter_password() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		dp.Password("anush");
	}

	@When("^User enter confirmpwd$")
	public void user_enter_confirmpwd() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		dp.conpwd("anush");
	}

	@Then("^Displays Error$")
	public void displays_Error() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		Thread.sleep(2000);
		WebElement lastn =driver.findElement(By.name("lastname"));
		String lastnme = lastn.getText();
		String ln = "Last Name must be between 1 and 32 characters!";
		if(lastnme.equals(ln))
			System.out.println("last name error verified");
		else
			System.out.println(" last name error msg is error");
		
		
		WebElement tphn =driver.findElement(By.id("input-telephone"));
		String tele = tphn.getText();
		String phnull = "Telephone must be between 3 and 32 characters!";
		if(tele.equals(phnull))
			System.out.println("Phone Number error verified");
		else
			System.out.println(" error msg is error");
		
		
	}
	
	
	
	@When("^User enters credentials$")
	public void user_enters_credentials(DataTable arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    // For automatic transformation, change DataTable to one of
	    // List<YourType>, List<List<E>>, List<Map<K,V>> or Map<K,V>.
	    // E,K,V must be a scalar (String, Integer, Date, enum etc)
	   /// throw new PendingException();
	}


	
}
