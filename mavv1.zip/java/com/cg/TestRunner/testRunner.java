package com.cg.TestRunner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions( 
		features = "C:\\ash_cg\\Modules\\Module 4\\TDD_WS\\login\\src\\main\\java\\com\\cg\\feature\\demo.feature",
		glue= "com.cg.stepdefinedemo")
public class testRunner {

	
}
