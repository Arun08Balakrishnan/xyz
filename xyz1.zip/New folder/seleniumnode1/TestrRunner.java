package seleniumnode1;

import static org.testng.Assert.assertEquals;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Hashtable;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import lab14.ReadFromExcel;

public class TestrRunner {
WebDriver driver;
DesiredCapabilities cap = null;	
@Parameters({"browser"})
	@BeforeMethod
	public void before(String browser) throws MalformedURLException, InterruptedException {
		if(browser.equals("chrome")) {
			cap = DesiredCapabilities.chrome();
		}
		else if(browser.equals("firefox")) {
			cap = DesiredCapabilities.firefox();
		}
		else if(browser.equals("InternetExplorer")) {
			cap = DesiredCapabilities.internetExplorer();
		}
		driver = new RemoteWebDriver(new URL("http://localhost:4446/wd/hub"),cap);
		
		//System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir")+"/Driver/chromedriver.exe");
		//driver = new ChromeDriver();
		driver.get("https://demo.opencart.com");
		driver.findElement(By.xpath("//*[@id=\"top-links\"]/ul/li[2]/a/i")).click();
		driver.findElement(By.xpath("//*[@id=\"top-links\"]/ul/li[2]/ul/li[2]/a")).click();
		
		
	}
	@Test(dataProvider="AcceptUserDetails")
	public void YourStore(Hashtable<String, String> tb) throws InterruptedException{
		
		//driver.findElement(By.xpath("//*[@id=\"top-links\"]/ul/li[2]/a/i")).click();
		//driver.findElement(By.xpath("//*[@id=\"top-links\"]/ul/li[2]/ul/li[2]/a")).click();
		WebElement firstTxt=driver.findElement(By.name("email"));
		firstTxt.clear();
		firstTxt.sendKeys(tb.get("Email"));
		WebElement secondTxt=driver.findElement(By.name("password"));
		secondTxt.clear();
		secondTxt.sendKeys(tb.get("Password"));
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"content\"]/div/div[2]/div/form/input")).click();
		String ActualTitle = driver.getTitle();
		String ExpectedTitle = "My Account";
		if(ActualTitle.equals(ExpectedTitle)) {
			System.out.println("Valid Input");
		}
		else {
			System.out.println("Invalid Input with Warning: No match for E-Mail Address and/or Password.");
		}
	}
	
	@DataProvider
	public Object[][] AcceptUserDetails() throws IOException {
		
		String filename ="Details.xlsx";
		String filepath= System.getProperty("user.dir")+"/src/seleniumd1";
		String sheetname = "Sheet1";
		return ReadFromExcel.ReadExcelData(filepath, filename, sheetname);

}
}